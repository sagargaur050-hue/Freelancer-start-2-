export const PLATFORM_NAME = "Meri Freelance Site";
export const PLATFORM_UPI_ID = "yourupi@upi"; // change this easily later
export const PLATFORM_QR_IMAGE = ""; // optional public URL to QR image
export const PLATFORM_PHONE = "+91-9876543210";